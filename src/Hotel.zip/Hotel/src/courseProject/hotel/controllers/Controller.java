package courseProject.hotel.controllers;

public class Controller {
}
