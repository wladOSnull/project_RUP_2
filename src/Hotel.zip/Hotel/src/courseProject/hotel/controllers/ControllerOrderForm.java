package courseProject.hotel.controllers;

import courseProject.hotel.SQL.SQLmain;
import courseProject.hotel.pojo.Client;
import courseProject.hotel.pojo.Orders;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.ZoneId;
import java.util.Hashtable;

public class ControllerOrderForm {

    // data
    private static Orders order;
    private static Client client;

    // FXML
    public Button buttonCancel;
    public Button buttonOK;
    public TextField textFieldName;
    public TextField textFieldSurname;
    public TextField textFieldNumber;
    public TextField textFieldPassport;
    public TextField textFieldAddress;
    public TextField textFieldCitizenship;
    public TextField textFieldWish;
    public TextField textFieldID;
    public DatePicker dataPickerArrival;
    public DatePicker dataPickerDeparture;
    public Label labelCheck;
    public ChoiceBox choiceBoxTarget;
    public ChoiceBox choiceBoxTypeRoom;
    public ChoiceBox choiceBoxTypePayment;
    public ChoiceBox choiceBoxStatus;

    // SQL
    public static SQLmain mSQL;

    // Boxes
    private Hashtable<String, String> listTarget;
    private Hashtable<String, String> listTypeRoom;
    private Hashtable<String, String> listTypePayment;
    private Hashtable<String, String> listStatus;

    // actions
    public void actionOK() {

        fillOrder();

        actionClose();
    }

    public void actionClose() {
        Stage stage = (Stage) buttonCancel.getScene().getWindow();
        stage.close();
    }

    // methods
    @FXML
    public void initialize() {

        listTarget = new Hashtable<String, String>();
        mSQL.getTarget().forEach((str) -> {

            choiceBoxTarget.getItems().addAll(str.getTargetDesc());
            listTarget.put(str.getTargetDesc(), str.getTargetID());
        });

        listTypeRoom = new Hashtable<String, String>();
        mSQL.getTypeRoom().forEach((str) -> {
            choiceBoxTypeRoom.getItems().addAll(str.getTypeRoomDesc().concat(" x:").concat(str.getNumberPerson()).concat(" p:").concat(str.getPrice()));
            listTypeRoom.put(str.getTypeRoomDesc().concat(" x:").concat(str.getNumberPerson()).concat(" p:").concat(str.getPrice()), str.getTypeRoomID());
        });

        listTypePayment = new Hashtable<String, String>();
        mSQL.getTypePayment().forEach((str) -> {
            choiceBoxTypePayment.getItems().addAll(str.getTypePaymentDesc());
            listTypePayment.put(str.getTypePaymentDesc(), str.getTypePaymentID());
        });

        listStatus = new Hashtable<String, String>();
        mSQL.getStatus().forEach((str) -> {
            choiceBoxStatus.getItems().addAll(str.getStatusDesc());
            listStatus.put(str.getStatusDesc(), str.getStatusID());
        });
    }

    public void display(javafx.scene.control.MenuBar menuBarMainWindow, SQLmain arg) {

        System.out.println("New order");

        try {
            Stage parent = (Stage) menuBarMainWindow.getScene().getWindow();

            Stage stage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("../fxml/orderForm.fxml"));
//            Parent root = FXMLLoader.load(getClass().getResource("../fxml/test.fxml"));
            stage.setTitle("New order");
            stage.setMinWidth(430);
            stage.setMinHeight(330);
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(parent);

            stage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }

        mSQL = arg;
    }

    private void fillOrder() {
        java.util.Date date = java.util.Date.from(dataPickerArrival.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
        java.sql.Date sqlDateArrival = new java.sql.Date(date.getTime());
        System.out.print("DATE: " + sqlDateArrival.toString() + " / ");

        date = java.util.Date.from(dataPickerDeparture.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
        java.sql.Date sqlDateDeparture = new java.sql.Date(date.getTime());
        System.out.println("DATE: " + sqlDateArrival.toString());

        String target = (String) choiceBoxTarget.getSelectionModel().getSelectedItem();
        target = listTarget.get(choiceBoxTarget.getSelectionModel().getSelectedItem());

        String query = "INSERT INTO Client(ClientID, FirstName, SurName, Address, Passport, Number, Citizenship, Target) value(" +
                textFieldID.getText() + ", '" +
                textFieldName.getText() + "', '" +
                textFieldSurname.getText() + "', '" +
                textFieldAddress.getText() + "', '" +
                textFieldPassport.getText() + "', '" +
                textFieldNumber.getText() + "', '" +
                textFieldCitizenship.getText() + "', " +
                target + ")";

        System.out.println("INSERT Client: " + query);
        mSQL.updateExecute(query);


        query = "INSERT INTO Orders(Client, TypeRoom, TypePayment, Status, DateArrival, DateDeparture, Wish, Totally) value(" +
                textFieldID.getText() + ", " +
                listTypeRoom.get(choiceBoxTypeRoom.getSelectionModel().getSelectedItem()) + ", " +
                listTypePayment.get(choiceBoxTypePayment.getSelectionModel().getSelectedItem()) + ", " +
                listStatus.get(choiceBoxStatus.getSelectionModel().getSelectedItem()) + ", '" +
                sqlDateArrival.toString() + "', '" +
                sqlDateDeparture.toString() + "', '" +
                textFieldWish.getText() + "', " +
                "0" + ")";

        System.out.println("INSERT Orders: " + query);
        mSQL.updateExecute(query);

/*       String select;

        try{
            select = "SELECT max(OrderID) FROM Orders";
            ResultSet rs = mSQL.selectExecute(select);

            rs.next();
            String cli = rs.getString("max(OrderID)");

            query = "UPDATE TypeRoom SET TypeRoom.OrderID=" + cli + " WHERE TypeRoomID=" + listTypeRoom.get(choiceBoxTypeRoom.getSelectionModel().getSelectedItem());
            System.out.println("UPDATE rooms: " + query);
            mSQL.updateExecute(query);

        } catch (SQLException ex){
            ex.printStackTrace();

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
*/

    }
}
