package courseProject.hotel.controllers;

import courseProject.hotel.SQL.SQLmain;
import courseProject.hotel.pojo.LoginForm;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;

public class ControllerLoginForm {

    // user input info
    public TextField textFieldUser;
    public PasswordField textFieldPass;
    public TextField textFieldHost;
    public TextField textFieldPort;
    public TextField textFieldSchema;

    // database
    private static SQLmain mSQL = null;

    // account
    private static LoginForm account;
    public Label labelLoginStatus;

    // actions
    public void actionLogin(){

        fillAccount();

        try{
            mSQL = new SQLmain(account);

        } catch (SQLException ex){
//            System.out.println("CATCH");
            mSQL = null;
            labelLoginStatus.setText("Check the entered data");
            labelLoginStatus.setTextFill(Color.web("#A22100"));

            return;
        }

        close();
    }

    @FXML
    public void actionEnter(KeyEvent e)
    {
//        System.out.println("KEY");
        if(e.getCode() == KeyCode.ENTER)
        {
//            System.out.println("ENTER");
            actionLogin();
        } else if (e.getCode() == KeyCode.ESCAPE)
        {
            close();
        }
    }

    public void actionClearLabelStatus(){
        labelLoginStatus.setText("");
        labelLoginStatus.setTextFill(Color.web("#FFFFFF"));
    }

    // methods
    public void display(javafx.scene.control.MenuBar menuBarMainWindow){

        System.out.println("LogIn");

        try {
            Stage parent = (Stage) menuBarMainWindow.getScene().getWindow();

            Stage stage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("../fxml/loginForm.fxml"));
//            Parent root = FXMLLoader.load(getClass().getResource("../fxml/test.fxml"));
            stage.setTitle("Log in");
            stage.setMinWidth(300);
            stage.setMinHeight(250);
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(parent);

            stage.showAndWait();

        } catch (IOException e){
            e.printStackTrace();
        }

    }

    private void close(){
        Stage stage = (Stage) labelLoginStatus.getScene().getWindow();
        stage.close();
    }

    private void fillAccount(){

        account = new LoginForm(textFieldUser.getText(),
                textFieldPass.getText(),
                textFieldHost.getText(),
                textFieldPort.getText(),
                textFieldSchema.getText());
    }

    public static LoginForm getAccount() {
        return account;
    }

    public static SQLmain getmSQL(){
        return mSQL;
    }

}
