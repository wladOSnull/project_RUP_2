package courseProject.hotel.controllers;

import courseProject.hotel.SQL.SQLmain;
import courseProject.hotel.pojo.Account;
import courseProject.hotel.pojo.Client;
import courseProject.hotel.pojo.PrettyTablesOfOrders;
import courseProject.hotel.pojo.TableOfRooms;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;


public class ControllerMainWindow {

    @FXML
    public javafx.scene.control.MenuBar menuBarMainWindow;
    public Menu menuEdit;
    public TableView tableViewRooms;
    public TableView tableViewOrders;
    public TableView tableViewClients;
    public TabPane tabPane;
    public Tab tabRooms;
    public Tab tabOrders;
    public Tab tabClients;
    public MenuItem menuItemLogin;
    public MenuItem menuItemLogout;
    public Button buttonAddOrder;
    public Button buttonChangeOrder;
    public Button buttonRemoveOrder;

    // controllers
    private ControllerLoginForm loginForm;
    private ControllerTableEditor editorWindow;
    private ControllerOrderForm orderForm;
    private ControllerChange change;

    // database
    private SQLmain mSQL;

    // main
    String titleWindow;

    @FXML
    public void initialize(){

        loginForm = new ControllerLoginForm();
        editorWindow = new ControllerTableEditor();
        orderForm = new ControllerOrderForm();
        change = new ControllerChange();

        cleanTableOfRooms();
        cleanPrettyOrdersTable();
        cleanClientTable();

    }

    // actions
    public void actionAbout(){
        System.out.println("About this program");

        try {
            Stage parent = (Stage) menuBarMainWindow.getScene().getWindow();

            Stage stage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("../fxml/about.fxml"));
//            Parent root = FXMLLoader.load(getClass().getResource("../fxml/test.fxml"));
            stage.setTitle("About");
            stage.setMinWidth(460);
            stage.setMinHeight(154);
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(parent);

            stage.showAndWait();

        } catch (IOException e){
            e.printStackTrace();
        }
    }

    public void actionQuit(){
        Stage stage = (Stage) menuBarMainWindow.getScene().getWindow();

        mSQL.endConnection();
        stage.close();
    }

    public void actionLogIn(){

        titleWindow = ((Stage)menuBarMainWindow.getScene().getWindow()).getTitle();
        loginForm.display(menuBarMainWindow);

        mSQL = ControllerLoginForm.getmSQL();
        if (mSQL == null) return;

        System.out.println("Received: " + ControllerLoginForm.getAccount().toString());
        changeControl();
    }

    public void actionLogOut(){
        System.out.println("LogOut");

        setStart();
        cleanTableOfRooms();
        ((Stage)menuBarMainWindow.getScene().getWindow()).setTitle(titleWindow);
    }

    public void actionEditDefaultTable(){

        editorWindow.display(menuBarMainWindow, mSQL);
    }

    public void actionNewOrder(){

        ControllerOrderForm.mSQL = mSQL;
        orderForm.display(menuBarMainWindow, mSQL);
        showPrettyOrdersTable();
    }

    public void actionRemove(){

        String query;
        PrettyTablesOfOrders ord = (PrettyTablesOfOrders) tableViewOrders.getSelectionModel().getSelectedItem();
        System.out.println("ID : " + ord.getOrderID());
        try{
            query = "SELECT Client FROM Orders WHERE OrderID=" + ord.getOrderID();
            ResultSet rs = mSQL.selectExecute(query);

            rs.next();
            String cli = rs.getString("Client");

            query = "update TypeRoom set TypeRoom.OrderID = null where TypeRoom.OrderID=" + ord.getOrderID();
            System.out.println("DELETE ID: " + query);
            mSQL.updateExecute(query);

            query = "DELETE FROM Orders WHERE OrderID=" + ord.getOrderID();
            System.out.println("DELETE ID: " + query);
            mSQL.updateExecute(query);

            query = "DELETE FROM Client WHERE ClientID=" + cli;
            System.out.println("DELETE ID: " + query);
            mSQL.updateExecute(query);

        } catch (SQLException ex){
            ex.printStackTrace();

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        showPrettyOrdersTable();

    }

    public void actionRemoveClient(){

        Client ord = (Client) tableViewClients.getSelectionModel().getSelectedItem();
        String query = "DELETE FROM Client WHERE ClientID=" + ord.getClientID();
        mSQL.updateExecute(query);
        System.out.println("Remove client: " + query);

        showClientTable();
    }

    public void actionChange(){

        String query;
        PrettyTablesOfOrders ord = (PrettyTablesOfOrders) tableViewOrders.getSelectionModel().getSelectedItem();
        System.out.println("CHANGE : " + ord.getOrderID());

            query = "SELECT * FROM Orders WHERE OrderID=" + ord.getOrderID();
            ResultSet rs = mSQL.selectExecute(query);

            ControllerChange.mSQL = mSQL;
            ControllerChange.rs = rs;
            change.display(menuBarMainWindow, mSQL, rs);

            showPrettyOrdersTable();

    }

    // set control
    private void changeControl(){

        ObservableList<Account> profiles = mSQL.getProfiles();
        ControllerLoginForm.getAccount().getUser();

        int idProfile = -1;

        for (Account profile: profiles){
            if (profile.getUser().equals(ControllerLoginForm.getAccount().getUser()))
            {
                idProfile = Integer.parseInt(profile.getId());
                break;
            }
        }

        switch (idProfile){
            case 1:
                System.out.println("ADMIN");
                setAdmin();
                ((Stage)menuBarMainWindow.getScene().getWindow()).setTitle(titleWindow + " (ADMIN)");
                break;

            case 2:
                System.out.println("RECEPTION");
                setReception();
                ((Stage)menuBarMainWindow.getScene().getWindow()).setTitle(titleWindow + " (RECEPTION)");
                break;

            case 3:
                System.out.println("SERVICE");
                setService();
                ((Stage)menuBarMainWindow.getScene().getWindow()).setTitle(titleWindow + " (SERVICE)");
                break;

            default:
                System.out.println("error SWITCH");
//                ((Stage)menuBarMainWindow.getScene().getWindow()).setTitle(((Stage)menuBarMainWindow.getScene().getWindow()).getTitle() + " (...)");
                return;
        }

        menuItemLogin.setDisable(true);
        menuItemLogout.setDisable(false);
    }

    private void setAdmin(){

        menuEdit.setDisable(false);
//        tabRooms.setDisable(false);
//        tabOrders.setDisable(false);
//        showTableRooms();
    }

    private void setReception(){
        tabRooms.setDisable(false);
        tabOrders.setDisable(false);
        tabClients.setDisable(false);

        showTableRooms();
        showPrettyOrdersTable();
        showClientTable();
    }

    private void setService(){

        tabRooms.setDisable(false);
        showTableRooms();
    }

    private void setStart(){

        menuEdit.setDisable(true);
        tabRooms.setDisable(true);
        tabOrders.setDisable(true);
        tabClients.setDisable(true);
        menuItemLogin.setDisable(false);
        menuItemLogout.setDisable(true);
        tabPane.getSelectionModel().select(0);
    }

    /**
     * Rooms table
     * */
    // draw table
    private void makeHeaderTableRooms(){

            cleanTableOfRooms();
            TableColumn column;

            column = new TableColumn("Number");
            column.setCellValueFactory(new PropertyValueFactory<TableOfRooms, String>("hotelRoom"));
            tableViewRooms.getColumns().add(column);

            column = new TableColumn("Description");
            column.setCellValueFactory(new PropertyValueFactory<TableOfRooms, String>("typeRoomDesc"));
            tableViewRooms.getColumns().add(column);

            column = new TableColumn("Status");
            column.setCellValueFactory(new PropertyValueFactory<TableOfRooms, String>("Status"));
            tableViewRooms.getColumns().add(column);

    }

    public void showTableRooms(){

        makeHeaderTableRooms();

        try{
            System.out.println("Draw table of rooms");
            tableViewRooms.setItems(mSQL.getTableForStaff());

        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage());
        }
    }

    private void cleanTableOfRooms(){
        tableViewRooms.getColumns().clear();

    }

    private void cleanPrettyOrdersTable(){
        tableViewOrders.getColumns().clear();

    }

    private void cleanClientTable(){
        tableViewClients.getColumns().clear();
    }

    /**
     * Client table
     * */
    // draw table
    private void makeHeaderClientTable(){

        cleanClientTable();
        TableColumn column;

        column = new TableColumn("ID");
        column.setCellValueFactory(new PropertyValueFactory<Client, String>("ClientID"));
        tableViewClients.getColumns().add(column);

        column = new TableColumn("First name");
        column.setCellValueFactory(new PropertyValueFactory<Client, String>("FirstName"));
        tableViewClients.getColumns().add(column);

        column = new TableColumn("Surname");
        column.setCellValueFactory(new PropertyValueFactory<Client, String>("SurName"));
        tableViewClients.getColumns().add(column);

        column = new TableColumn("Address");
        column.setCellValueFactory(new PropertyValueFactory<Client, String>("Address"));
        tableViewClients.getColumns().add(column);

        column = new TableColumn("Passport");
        column.setCellValueFactory(new PropertyValueFactory<Client, String>("Passport"));
        tableViewClients.getColumns().add(column);

        column = new TableColumn("Number");
        column.setCellValueFactory(new PropertyValueFactory<Client, String>("Number"));
        tableViewClients.getColumns().add(column);

        column = new TableColumn("Citizenship");
        column.setCellValueFactory(new PropertyValueFactory<Client, String>("Citizenship"));
        tableViewClients.getColumns().add(column);

        column = new TableColumn("Target");
        column.setCellValueFactory(new PropertyValueFactory<Client, String>("Target"));
        tableViewClients.getColumns().add(column);
    }

    public void showClientTable(){

        makeHeaderClientTable();

        try{
            System.out.println("Draw PRETTY table of client");
            tableViewClients.setItems(mSQL.getClient());

        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage());
        }
    }

    /**
     * Pretty order table
     * */
    // draw table
    private void makeHeaderPrettyOrdersTable(){

        cleanPrettyOrdersTable();
        TableColumn column;

        column = new TableColumn("ID");
        column.setCellValueFactory(new PropertyValueFactory<PrettyTablesOfOrders, String>("OrderID"));
        tableViewOrders.getColumns().add(column);

        column = new TableColumn("Surname");
        column.setCellValueFactory(new PropertyValueFactory<PrettyTablesOfOrders, String>("SurName"));
        tableViewOrders.getColumns().add(column);

        column = new TableColumn("Room");
        column.setCellValueFactory(new PropertyValueFactory<PrettyTablesOfOrders, String>("RoomNumber"));
        tableViewOrders.getColumns().add(column);

        column = new TableColumn("Status");
        column.setCellValueFactory(new PropertyValueFactory<PrettyTablesOfOrders, String>("StatusDesc"));
        tableViewOrders.getColumns().add(column);

        column = new TableColumn("Totally");
        column.setCellValueFactory(new PropertyValueFactory<PrettyTablesOfOrders, String>("Totally"));
        tableViewOrders.getColumns().add(column);
    }

    public void showPrettyOrdersTable(){

        makeHeaderPrettyOrdersTable();

        try{
            System.out.println("Draw PRETTY table of orders");
            tableViewOrders.setItems(mSQL.getPrettyOrdersTable());

        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage());
        }
    }

    /**
     * Orders table
     * */
    // draw table
/*    private void makeHeaderTableOrders(){

        ResultSet description = SQLmain.getDescriptionOfTable("Orders");

        try {
            description.next();

            String nameColumn;
            TableColumn column;

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellValueFactory(new PropertyValueFactory<Status, String>(nameColumn));
            description.next();
            tableViewOrders.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
//            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<Status, String>(nameColumn));
            description.next();
            tableViewOrders.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
//            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<Status, String>(nameColumn));
            description.next();
            tableViewOrders.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
//            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<Status, String>(nameColumn));
            description.next();
            tableViewOrders.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
//            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<Status, String>(nameColumn));
            description.next();
            tableViewOrders.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
//            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<Status, String>(nameColumn));
            description.next();
            tableViewOrders.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
//            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<Status, String>(nameColumn));
            description.next();
            tableViewOrders.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
//            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<Status, String>(nameColumn));
            description.next();
            tableViewOrders.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
//            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<Status, String>(nameColumn));
            description.next();
            tableViewOrders.getColumns().add(column);

        } catch (SQLException ex){
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
    }

    private void showTableOrders(){

        makeHeaderTableOrders();

        try{
            System.out.println("Draw table of orders");
            tableViewOrders.setItems(mSQL.getOrders());

        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage());
        }
    }
*/
}
