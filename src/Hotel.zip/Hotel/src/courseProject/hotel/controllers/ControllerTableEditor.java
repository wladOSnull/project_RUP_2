package courseProject.hotel.controllers;

import courseProject.hotel.SQL.SQLmain;
import courseProject.hotel.pojo.*;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ControllerTableEditor {

    public TableView tableViewEditable;
    private javafx.scene.control.MenuBar parrentWindow;
    private static SQLmain mSQL;

    // methods
    public void display(javafx.scene.control.MenuBar menuBarMainWindow, SQLmain arg){

        System.out.println("Editor");
        parrentWindow = menuBarMainWindow;
        mSQL = arg;

        try {
            Stage parent = (Stage) parrentWindow.getScene().getWindow();

            Stage stage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("../fxml/tableEditor.fxml"));
            stage.setTitle("ADMIN Edit panel");
            stage.setMinWidth(300);
            stage.setMinHeight(250);
//            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(parent);

            stage.showAndWait();

        } catch (IOException e){
            e.printStackTrace();
        }
    }

    public void actionQuit(){
        Stage stage = (Stage) tableViewEditable.getScene().getWindow();
        stage.close();
    }

    private void cleanTable(){

        tableViewEditable.getColumns().clear();
    }

    /**
     * TypeRoom table
     */

    // actions
    public void actionRoom(){

        System.out.println("actionRoom");
        cleanTable();
        tableViewEditable.setEditable(true);
        showTypeRoom();
    }

    // draw table
    private void makeHeaderTypeRoom(){

        ResultSet description = SQLmain.getDescriptionOfTable("TypeRoom");

        try{
            description.next();

            String nameColumn;
            TableColumn column;

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellValueFactory(new PropertyValueFactory<TypeRoom, String>(nameColumn));
            description.next();
            tableViewEditable.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<TypeRoom, String>(nameColumn));
            column.setOnEditCommit(
                    new EventHandler<TableColumn.CellEditEvent<TypeRoom, String>>() {
                        @Override
                        public void handle(TableColumn.CellEditEvent<TypeRoom, String> t) {
                            ((TypeRoom) t.getTableView().getItems().get(
                                    t.getTablePosition().getRow())
                            ).setRoomNumber(t.getNewValue());

                            String query = "UPDATE TypeRoom SET "
                                    + "RoomNumber=" + t.getRowValue().getRoomNumber() + ","
                                    + "TypeRoomDesc='" + t.getRowValue().getTypeRoomDesc() + "',"
                                    + "NumberPerson=" + t.getRowValue().getNumberPerson() + ","
                                    + "Price=" + t.getRowValue().getPrice()
                                    + " WHERE TypeRoomID=" + t.getRowValue().getTypeRoomID();

                            System.out.println("NEW DATA:: " + query);

                            mSQL.updateExecute(query);
                        }
                    }
            );
            description.next();
            tableViewEditable.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<TypeRoom, String>(nameColumn));
            column.setOnEditCommit(
                    new EventHandler<TableColumn.CellEditEvent<TypeRoom, String>>() {
                        @Override
                        public void handle(TableColumn.CellEditEvent<TypeRoom, String> t) {
                            ((TypeRoom) t.getTableView().getItems().get(
                                    t.getTablePosition().getRow())
                            ).setTypeRoomDesc(t.getNewValue());

                            String query = "UPDATE TypeRoom SET "
                                    + "RoomNumber=" + t.getRowValue().getRoomNumber() + ","
                                    + "TypeRoomDesc='" + t.getRowValue().getTypeRoomDesc() + "',"
                                    + "NumberPerson=" + t.getRowValue().getNumberPerson() + ","
                                    + "Price=" + t.getRowValue().getPrice()
                                    + " WHERE TypeRoomID=" + t.getRowValue().getTypeRoomID();

                            System.out.println("NEW DATA:: " + query);

                            mSQL.updateExecute(query);
                        }
                    }
            );
            description.next();
            tableViewEditable.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<TypeRoom, String>(nameColumn));
            column.setOnEditCommit(
                    new EventHandler<TableColumn.CellEditEvent<TypeRoom, String>>() {
                        @Override
                        public void handle(TableColumn.CellEditEvent<TypeRoom, String> t) {
                            ((TypeRoom) t.getTableView().getItems().get(
                                    t.getTablePosition().getRow())
                            ).setNumberPerson(t.getNewValue());
                            String query = "UPDATE TypeRoom SET "
                                    + "RoomNumber=" + t.getRowValue().getRoomNumber() + ","
                                    + "TypeRoomDesc='" + t.getRowValue().getTypeRoomDesc() + "',"
                                    + "NumberPerson=" + t.getRowValue().getNumberPerson() + ","
                                    + "Price=" + t.getRowValue().getPrice()
                                    + " WHERE TypeRoomID=" + t.getRowValue().getTypeRoomID();

                            System.out.println("NEW DATA:: " + query);

                            mSQL.updateExecute(query);
                        }
                    }
            );
            description.next();
            tableViewEditable.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<TypeRoom, String>(nameColumn));
            column.setOnEditCommit(
                    new EventHandler<TableColumn.CellEditEvent<TypeRoom, String>>() {
                        @Override
                        public void handle(TableColumn.CellEditEvent<TypeRoom, String> t) {
                            ((TypeRoom) t.getTableView().getItems().get(
                                    t.getTablePosition().getRow())
                            ).setPrice(t.getNewValue());
                            String query = "UPDATE TypeRoom SET "
                                    + "RoomNumber=" + t.getRowValue().getRoomNumber() + ","
                                    + "TypeRoomDesc='" + t.getRowValue().getTypeRoomDesc() + "',"
                                    + "NumberPerson=" + t.getRowValue().getNumberPerson() + ","
                                    + "Price=" + t.getRowValue().getPrice()
                                    + " WHERE TypeRoomID=" + t.getRowValue().getTypeRoomID();

                            System.out.println("NEW DATA:: " + query);

                            mSQL.updateExecute(query);
                        }
                    }
            );
            description.next();
            tableViewEditable.getColumns().add(column);

        } catch (SQLException ex){
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

    }

    private void showTypeRoom(){

        makeHeaderTypeRoom();

        try{
            System.out.println("Draw table of rooms");
            tableViewEditable.setItems(mSQL.getTypeRoom());

        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage());
        }
    }

    /**
    * Target table
    * */

    // actions
    public void actionTarget(){
        System.out.println("actionTarget");
        cleanTable();
        tableViewEditable.setEditable(true);
        showTarget();
    }

    // draw table
    private void makeHeaderTarget(){
        ResultSet description = SQLmain.getDescriptionOfTable("Target");

        try {
            description.next();

            String nameColumn;
            TableColumn column;

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellValueFactory(new PropertyValueFactory<Target, String>(nameColumn));
            description.next();
            tableViewEditable.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<Target, String>(nameColumn));
            column.setOnEditCommit(
                    new EventHandler<TableColumn.CellEditEvent<Target, String>>() {
                        @Override
                        public void handle(TableColumn.CellEditEvent<Target, String> t) {
                            ((Target) t.getTableView().getItems().get(
                                    t.getTablePosition().getRow())
                            ).setTargetDesc(t.getNewValue());

                            String query = "UPDATE Target SET "
                                    + "TargetDesc='" + t.getRowValue().getTargetDesc()
                                    + "' WHERE TargetID=" + t.getRowValue().getTargetID();

                            System.out.println("NEW DATA:: " + query);

                            mSQL.updateExecute(query);
                        }
                    }
            );
            description.next();
            tableViewEditable.getColumns().add(column);

        } catch (SQLException ex){
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
    }

    private void showTarget(){

        makeHeaderTarget();

        try{
            System.out.println("Draw table of target");
            tableViewEditable.setItems(mSQL.getTarget());

        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage());
        }
    }

    /**
     * TypePayment table
     * */

    // actions
    public void actionTypePayment(){
        System.out.println("actionTypePayment");
        cleanTable();
        tableViewEditable.setEditable(true);
        showTypePayment();
    }

    // draw table
    private void makeHeaderTypePayment(){
        ResultSet description = SQLmain.getDescriptionOfTable("TypePayment");

        try {
            description.next();

            String nameColumn;
            TableColumn column;

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellValueFactory(new PropertyValueFactory<TypePayment, String>(nameColumn));
            description.next();
            tableViewEditable.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<TypePayment, String>(nameColumn));
            column.setOnEditCommit(
                    new EventHandler<TableColumn.CellEditEvent<TypePayment, String>>() {
                        @Override
                        public void handle(TableColumn.CellEditEvent<TypePayment, String> t) {
                            ((TypePayment) t.getTableView().getItems().get(
                                    t.getTablePosition().getRow())
                            ).setTypePaymentDesc(t.getNewValue());

                            String query = "UPDATE TypePayment SET "
                                    + "TypePaymentDesc='" + t.getRowValue().getTypePaymentDesc()
                                    + "' WHERE TypePaymentID=" + t.getRowValue().getTypePaymentID();

                            System.out.println("NEW DATA:: " + query);

                            mSQL.updateExecute(query);
                        }
                    }
            );
            description.next();
            tableViewEditable.getColumns().add(column);

        } catch (SQLException ex){
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
    }

    private void showTypePayment(){

        makeHeaderTypePayment();

        try{
            System.out.println("Draw table of type payment");
            tableViewEditable.setItems(mSQL.getTypePayment());

        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage());
        }
    }

    /**
     * Status table
     * */

    // actions
    public void actionStatus(){
        System.out.println("actionStatus");
        cleanTable();
        tableViewEditable.setEditable(true);
        showStatus();
    }

    // draw table
    private void makeHeaderStatus(){
        ResultSet description = SQLmain.getDescriptionOfTable("Status");

        try {
            description.next();

            String nameColumn;
            TableColumn column;

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellValueFactory(new PropertyValueFactory<Status, String>(nameColumn));
            description.next();
            tableViewEditable.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<Status, String>(nameColumn));
            column.setOnEditCommit(
                    new EventHandler<TableColumn.CellEditEvent<Status, String>>() {
                        @Override
                        public void handle(TableColumn.CellEditEvent<Status, String> t) {
                            ((Status) t.getTableView().getItems().get(
                                    t.getTablePosition().getRow())
                            ).setStatusDesc(t.getNewValue());

                            String query = "UPDATE Status SET "
                                    + "StatusDesc='" + t.getRowValue().getStatusDesc()
                                    + "' WHERE StatusID=" + t.getRowValue().getStatusID();

                            System.out.println("NEW DATA:: " + query);

                            mSQL.updateExecute(query);
                        }
                    }
            );
            description.next();
            tableViewEditable.getColumns().add(column);

        } catch (SQLException ex){
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
    }

    private void showStatus(){

        makeHeaderStatus();

        try{
            System.out.println("Draw table of status");
            tableViewEditable.setItems(mSQL.getStatus());

        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage());
        }
    }

    /**
     * TypeSpecialOrders table
     * */

    // actions
    public void actionType(){
        System.out.println("actionType");
        cleanTable();
        tableViewEditable.setEditable(true);
        showType();
    }

    // draw table
    private void makeHeaderType(){
        ResultSet description = SQLmain.getDescriptionOfTable("TypeSpecialOrders");

        try {
            description.next();

            String nameColumn;
            TableColumn column;

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellValueFactory(new PropertyValueFactory<TypeSpecialOrders, String>(nameColumn));
            description.next();
            tableViewEditable.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<TypeSpecialOrders, String>(nameColumn));
            column.setOnEditCommit(
                    new EventHandler<TableColumn.CellEditEvent<TypeSpecialOrders, String>>() {
                        @Override
                        public void handle(TableColumn.CellEditEvent<TypeSpecialOrders, String> t) {
                            ((TypeSpecialOrders) t.getTableView().getItems().get(
                                    t.getTablePosition().getRow())
                            ).setTypeSpecialOrdersName(t.getNewValue());

                            String query = "UPDATE TypeSpecialOrders SET "
                                    + "TypeSpecialOrdersName='" + t.getRowValue().getTypeSpecialOrdersName()
                                    + "TypeSpecialOrdersDesc='" + t.getRowValue().getTypeSpecialOrdersDesc()
                                    + "' WHERE TypeSpecialOrdersID=" + t.getRowValue().getTypeSpecialOrdersID();

                            System.out.println("NEW DATA:: " + query);

                            mSQL.updateExecute(query);
                        }
                    }
            );
            description.next();
            tableViewEditable.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<TypeSpecialOrders, String>(nameColumn));
            column.setOnEditCommit(
                    new EventHandler<TableColumn.CellEditEvent<TypeSpecialOrders, String>>() {
                        @Override
                        public void handle(TableColumn.CellEditEvent<TypeSpecialOrders, String> t) {
                            ((TypeSpecialOrders) t.getTableView().getItems().get(
                                    t.getTablePosition().getRow())
                            ).setTypeSpecialOrdersDesc(t.getNewValue());

                            String query = "UPDATE TypeSpecialOrders SET "
                                    + "TypeSpecialOrdersName='" + t.getRowValue().getTypeSpecialOrdersName()
                                    + "TypeSpecialOrdersDesc='" + t.getRowValue().getTypeSpecialOrdersDesc()
                                    + "' WHERE TypeSpecialOrdersID=" + t.getRowValue().getTypeSpecialOrdersID();

                            System.out.println("NEW DATA:: " + query);

                            mSQL.updateExecute(query);
                        }
                    }
            );
            description.next();
            tableViewEditable.getColumns().add(column);

        } catch (SQLException ex){
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
    }

    private void showType(){

        makeHeaderType();

        try{
            System.out.println("Draw table of status");
            tableViewEditable.setItems(mSQL.getTypeSpecialOrders());

        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage());
        }
    }

    /**
     * SpecialOrders table
     * */

    // actions
    public void actionSpecial(){
        System.out.println("actionSpecial");
        cleanTable();
        tableViewEditable.setEditable(true);
        showSpecial();
    }

    // draw table
    private void makeHeaderSpecial(){

        ResultSet description = SQLmain.getDescriptionOfTable("SpecialOrders");

        try {
            description.next();

            String nameColumn;
            TableColumn column;

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellValueFactory(new PropertyValueFactory<SpecialOrders, String>(nameColumn));
            description.next();
            tableViewEditable.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<SpecialOrders, String>(nameColumn));
            column.setOnEditCommit(
                    new EventHandler<TableColumn.CellEditEvent<SpecialOrders, String>>() {
                        @Override
                        public void handle(TableColumn.CellEditEvent<SpecialOrders, String> t) {
                            ((SpecialOrders) t.getTableView().getItems().get(
                                    t.getTablePosition().getRow())
                            ).setSpecialOrdersName(t.getNewValue());

                            String query = "UPDATE SpecialOrders SET "
                                    + "SpecialOrdersName='" + t.getRowValue().getSpecialOrdersName()
                                    + "SpecialOrdersDesc='" + t.getRowValue().getSpecialOrdersDesc()
                                    + "Price=" + t.getRowValue().getPrice()
                                    + "SpecialOrdersType=" + t.getRowValue().getSpecialOrdersType()
                                    + " WHERE SpecialOrdersID=" + t.getRowValue().getSpecialOrdersID();

                            System.out.println("NEW DATA:: " + query);

                            mSQL.updateExecute(query);
                        }
                    }
            );
            description.next();
            tableViewEditable.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<SpecialOrders, String>(nameColumn));
            column.setOnEditCommit(
                    new EventHandler<TableColumn.CellEditEvent<SpecialOrders, String>>() {
                        @Override
                        public void handle(TableColumn.CellEditEvent<SpecialOrders, String> t) {
                            ((SpecialOrders) t.getTableView().getItems().get(
                                    t.getTablePosition().getRow())
                            ).setSpecialOrdersDesc(t.getNewValue());

                            String query = "UPDATE SpecialOrders SET "
                                    + "SpecialOrdersName='" + t.getRowValue().getSpecialOrdersName()
                                    + "SpecialOrdersDesc='" + t.getRowValue().getSpecialOrdersDesc()
                                    + "Price=" + t.getRowValue().getPrice()
                                    + "SpecialOrdersType=" + t.getRowValue().getSpecialOrdersType()
                                    + " WHERE SpecialOrdersID=" + t.getRowValue().getSpecialOrdersID();

                            System.out.println("NEW DATA:: " + query);

                            mSQL.updateExecute(query);
                        }
                    }
            );
            description.next();
            tableViewEditable.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<SpecialOrders, String>(nameColumn));
            column.setOnEditCommit(
                    new EventHandler<TableColumn.CellEditEvent<SpecialOrders, String>>() {
                        @Override
                        public void handle(TableColumn.CellEditEvent<SpecialOrders, String> t) {
                            ((SpecialOrders) t.getTableView().getItems().get(
                                    t.getTablePosition().getRow())
                            ).setPrice(t.getNewValue());

                            String query = "UPDATE SpecialOrders SET "
                                    + "SpecialOrdersName='" + t.getRowValue().getSpecialOrdersName()
                                    + "SpecialOrdersDesc='" + t.getRowValue().getSpecialOrdersDesc()
                                    + "Price=" + t.getRowValue().getPrice()
                                    + "SpecialOrdersType=" + t.getRowValue().getSpecialOrdersType()
                                    + " WHERE SpecialOrdersID=" + t.getRowValue().getSpecialOrdersID();

                            System.out.println("NEW DATA:: " + query);

                            mSQL.updateExecute(query);
                        }
                    }
            );
            description.next();
            tableViewEditable.getColumns().add(column);

            nameColumn = description.getString("Field");
            column = new TableColumn(nameColumn);
            column.setCellFactory(TextFieldTableCell.forTableColumn());
            column.setCellValueFactory(new PropertyValueFactory<SpecialOrders, String>(nameColumn));
            column.setOnEditCommit(
                    new EventHandler<TableColumn.CellEditEvent<SpecialOrders, String>>() {
                        @Override
                        public void handle(TableColumn.CellEditEvent<SpecialOrders, String> t) {
                            ((SpecialOrders) t.getTableView().getItems().get(
                                    t.getTablePosition().getRow())
                            ).setSpecialOrdersType(t.getNewValue());

                            String query = "UPDATE SpecialOrders SET "
                                    + "SpecialOrdersName='" + t.getRowValue().getSpecialOrdersName()
                                    + "SpecialOrdersDesc='" + t.getRowValue().getSpecialOrdersDesc()
                                    + "Price=" + t.getRowValue().getPrice()
                                    + "SpecialOrdersType=" + t.getRowValue().getSpecialOrdersType()
                                    + " WHERE SpecialOrdersID=" + t.getRowValue().getSpecialOrdersID();

                            System.out.println("NEW DATA:: " + query);

                            mSQL.updateExecute(query);
                        }
                    }
            );
            description.next();
            tableViewEditable.getColumns().add(column);

        } catch (SQLException ex){
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
    }

    private void showSpecial(){

        makeHeaderSpecial();

        try{
            System.out.println("Draw table of special");
            tableViewEditable.setItems(mSQL.getSpecialOrders());

        } catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage());
        }
    }
}
