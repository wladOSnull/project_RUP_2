package courseProject.hotel.pojo;

import javafx.beans.property.SimpleStringProperty;

public class Status {
    private SimpleStringProperty StatusID;
    private SimpleStringProperty StatusDesc;

    public Status(SimpleStringProperty statusID,
                  SimpleStringProperty statusDesc) {
        StatusID = statusID;
        StatusDesc = statusDesc;
    }

    public Status(String statusID, String statusDesc){
        StatusID = new SimpleStringProperty(statusID);
        StatusDesc = new SimpleStringProperty(statusDesc);
    }

    public String getStatusID() {
        return StatusID.get();
    }

    public SimpleStringProperty statusIDProperty() {
        return StatusID;
    }

    public void setStatusID(String statusID) {
        this.StatusID.set(statusID);
    }

    public String getStatusDesc() {
        return StatusDesc.get();
    }

    public SimpleStringProperty statusDescProperty() {
        return StatusDesc;
    }

    public void setStatusDesc(String statusDesc) {
        this.StatusDesc.set(statusDesc);
    }

    @Override
    public String toString() {
        return "Status{" +
                "StatusID=" + StatusID +
                ", StatusDesc=" + StatusDesc +
                '}';
    }
}
