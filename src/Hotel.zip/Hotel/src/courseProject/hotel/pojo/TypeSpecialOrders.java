package courseProject.hotel.pojo;

import javafx.beans.property.SimpleStringProperty;

public class TypeSpecialOrders {
    private SimpleStringProperty TypeSpecialOrdersID;
    private SimpleStringProperty TypeSpecialOrdersName;
    private SimpleStringProperty TypeSpecialOrdersDesc;

    public TypeSpecialOrders(SimpleStringProperty typeSpecialOrdersID,
                             SimpleStringProperty typeSpecialOrdersName,
                             SimpleStringProperty typeSpecialOrdersDesc) {
        TypeSpecialOrdersID = typeSpecialOrdersID;
        TypeSpecialOrdersName = typeSpecialOrdersName;
        TypeSpecialOrdersDesc = typeSpecialOrdersDesc;
    }

    public TypeSpecialOrders(String typeSpecialOrdersID,
                             String typeSpecialOrdersName,
                             String typeSpecialOrdersDesc){
        TypeSpecialOrdersID = new SimpleStringProperty(typeSpecialOrdersID);
        TypeSpecialOrdersName = new SimpleStringProperty(typeSpecialOrdersName);
        TypeSpecialOrdersDesc = new SimpleStringProperty(typeSpecialOrdersDesc);
    }

    public String getTypeSpecialOrdersID() {
        return TypeSpecialOrdersID.get();
    }

    public SimpleStringProperty typeSpecialOrdersIDProperty() {
        return TypeSpecialOrdersID;
    }

    public void setTypeSpecialOrdersID(String typeSpecialOrdersID) {
        this.TypeSpecialOrdersID.set(typeSpecialOrdersID);
    }

    public String getTypeSpecialOrdersName() {
        return TypeSpecialOrdersName.get();
    }

    public SimpleStringProperty typeSpecialOrdersNameProperty() {
        return TypeSpecialOrdersName;
    }

    public void setTypeSpecialOrdersName(String typeSpecialOrdersName) {
        this.TypeSpecialOrdersName.set(typeSpecialOrdersName);
    }

    public String getTypeSpecialOrdersDesc() {
        return TypeSpecialOrdersDesc.get();
    }

    public SimpleStringProperty typeSpecialOrdersDescProperty() {
        return TypeSpecialOrdersDesc;
    }

    public void setTypeSpecialOrdersDesc(String typeSpecialOrdersDesc) {
        this.TypeSpecialOrdersDesc.set(typeSpecialOrdersDesc);
    }

    @Override
    public String toString() {
        return "TypeSpecialOrders{" +
                "TypeSpecialOrdersID=" + TypeSpecialOrdersID +
                ", TypeSpecialOrdersName=" + TypeSpecialOrdersName +
                ", TypeSpecialOrdersDesc=" + TypeSpecialOrdersDesc +
                '}';
    }
}
