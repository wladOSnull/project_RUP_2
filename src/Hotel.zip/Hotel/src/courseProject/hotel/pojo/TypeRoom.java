package courseProject.hotel.pojo;

import javafx.beans.property.SimpleStringProperty;

public class TypeRoom {
    private SimpleStringProperty TypeRoomID;
    private SimpleStringProperty RoomNumber;
    private SimpleStringProperty TypeRoomDesc;
    private SimpleStringProperty NumberPerson;
    private SimpleStringProperty Price;

    public TypeRoom(SimpleStringProperty typeRoomID,
                    SimpleStringProperty roomNumber,
                    SimpleStringProperty typeRoomDesc,
                    SimpleStringProperty numberPerson,
                    SimpleStringProperty price) {
        TypeRoomID = typeRoomID;
        RoomNumber = roomNumber;
        TypeRoomDesc = typeRoomDesc;
        NumberPerson = numberPerson;
        Price = price;
    }

    public TypeRoom(String typeRoomID,
                    String roomNumber,
                    String typeRoomDesc,
                    String numberPerson,
                    String price) {
        TypeRoomID = new SimpleStringProperty(typeRoomID);
        RoomNumber = new SimpleStringProperty(roomNumber);
        TypeRoomDesc = new SimpleStringProperty(typeRoomDesc);
        NumberPerson = new SimpleStringProperty(numberPerson);
        Price = new SimpleStringProperty(price);
    }

    public String getTypeRoomID() {
        return TypeRoomID.get();
    }

    public SimpleStringProperty typeRoomIDProperty() {
        return TypeRoomID;
    }

    public void setTypeRoomID(String typeRoomID) {
        this.TypeRoomID.set(typeRoomID);
    }

    public String getRoomNumber() {
        return RoomNumber.get();
    }

    public SimpleStringProperty roomNumberProperty() {
        return RoomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.RoomNumber.set(roomNumber);
    }

    public String getTypeRoomDesc() {
        return TypeRoomDesc.get();
    }

    public SimpleStringProperty typeRoomDescProperty() {
        return TypeRoomDesc;
    }

    public void setTypeRoomDesc(String typeRoomDesc) {
        this.TypeRoomDesc.set(typeRoomDesc);
    }

    public String getNumberPerson() {
        return NumberPerson.get();
    }

    public SimpleStringProperty numberPersonProperty() {
        return NumberPerson;
    }

    public void setNumberPerson(String numberPerson) {
        this.NumberPerson.set(numberPerson);
    }

    public String getPrice() {
        return Price.get();
    }

    public SimpleStringProperty priceProperty() {
        return Price;
    }

    public void setPrice(String price) {
        this.Price.set(price);
    }

    @Override
    public String toString() {
        return "TypeRoom{" +
                "TypeRoomID=" + TypeRoomID +
                ", TypeRoomDesc=" + TypeRoomDesc +
                ", NumberPerson=" + NumberPerson +
                ", Price=" + Price +
                '}';
    }
}
