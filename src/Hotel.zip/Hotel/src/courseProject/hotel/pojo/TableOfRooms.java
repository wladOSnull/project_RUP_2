package courseProject.hotel.pojo;

import javafx.beans.property.SimpleStringProperty;

public class TableOfRooms {

    private SimpleStringProperty hotelRoom;
    private SimpleStringProperty typeRoomDesc;
    private SimpleStringProperty status;

    public TableOfRooms() {}

    public TableOfRooms(SimpleStringProperty hotelRoom,
                        SimpleStringProperty typeRoomDesc,
                        SimpleStringProperty status) {
        this.hotelRoom = hotelRoom;
        this.typeRoomDesc = typeRoomDesc;
        this.status = status;
    }

    public TableOfRooms(String hotelRoom, String typeRoomDesc, String status){
        this.hotelRoom = new SimpleStringProperty(hotelRoom);
        this.typeRoomDesc = new SimpleStringProperty(typeRoomDesc);

        if (status == null)
            status = new String("--//--");
        this.status = new SimpleStringProperty(status);
    }

    public String getHotelRoom() {
        return hotelRoom.get();
    }

    public SimpleStringProperty hotelRoomProperty() {
        return hotelRoom;
    }

    public void setHotelRoom(String hotelRoom) {
        this.hotelRoom.set(hotelRoom);
    }

    public String getTypeRoomDesc() {
        return typeRoomDesc.get();
    }

    public SimpleStringProperty typeRoomDescProperty() {
        return typeRoomDesc;
    }

    public void setTypeRoomDesc(String typeRoomDesc) {
        this.typeRoomDesc.set(typeRoomDesc);
    }

    public String getStatus() {
        return status.get();
    }

    public SimpleStringProperty statusProperty() {
        return status;
    }

    public void setStatus(String status) {
        this.status.set(status);
    }

    @Override
    public String toString() {
        return "TableOfRooms{" +
                hotelRoom +
                ", " + typeRoomDesc +
                ", " + status +
                '}';
    }
}
