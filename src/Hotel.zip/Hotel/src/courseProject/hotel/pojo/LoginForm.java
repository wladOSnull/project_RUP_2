package courseProject.hotel.pojo;

import javafx.beans.property.SimpleStringProperty;

public class LoginForm {

    // fields
    private SimpleStringProperty user;
    private SimpleStringProperty password;
    private SimpleStringProperty host;
    private SimpleStringProperty port;
    private SimpleStringProperty schema;

    // constructors
    public LoginForm(SimpleStringProperty user,
                     SimpleStringProperty password,
                     SimpleStringProperty host,
                     SimpleStringProperty port,
                     SimpleStringProperty schema) {
        this.user = user;
        this.password = password;
        this.host = host;
        this.port = port;
        this.schema = schema;
    }

    public LoginForm(String user, String password, String host, String port, String schema){
        this.user = new SimpleStringProperty(user);
        this.password = new SimpleStringProperty(password);
        this.host = new SimpleStringProperty(host);
        this.port = new SimpleStringProperty(port);
        this.schema = new SimpleStringProperty(schema);
    }

    // get / set
    public String getUser() {
        return user.get();
    }

    public SimpleStringProperty userProperty() {
        return user;
    }

    public void setUser(String user) {
        this.user.set(user);
    }

    public String getPassword() {
        return password.get();
    }

    public SimpleStringProperty passwordProperty() {
        return password;
    }

    public void setPassword(String password) {
        this.password.set(password);
    }

    public String getHost() {
        return host.get();
    }

    public SimpleStringProperty hostProperty() {
        return host;
    }

    public void setHost(String host) {
        this.host.set(host);
    }

    public String getPort() {
        return port.get();
    }

    public SimpleStringProperty portProperty() {
        return port;
    }

    public void setPort(String port) {
        this.port.set(port);
    }

    public String getSchema() {
        return schema.get();
    }

    public SimpleStringProperty schemaProperty() {
        return schema;
    }

    public void setSchema(String schema) {
        this.schema.set(schema);
    }

    @Override
    public String toString() {
        return "LoginForm{" +
                "user=" + user +
                ", password=" + password +
                ", host=" + host +
                ", port=" + port +
                ", schema=" + schema +
                '}';
    }
}