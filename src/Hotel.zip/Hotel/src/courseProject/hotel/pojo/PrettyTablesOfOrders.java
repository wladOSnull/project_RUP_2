package courseProject.hotel.pojo;

import javafx.beans.property.SimpleStringProperty;

import java.net.SocketImpl;

public class PrettyTablesOfOrders {
    private SimpleStringProperty OrderID;
    private SimpleStringProperty SurName;
    private SimpleStringProperty RoomNumber;
    private SimpleStringProperty StatusDesc;
    private SimpleStringProperty Totally;

    public PrettyTablesOfOrders(SimpleStringProperty orderID,
                                SimpleStringProperty surName,
                                SimpleStringProperty roomNumber,
                                SimpleStringProperty statusDesc,
                                SimpleStringProperty totally) {
        OrderID = orderID;
        SurName = surName;
        RoomNumber = roomNumber;
        StatusDesc = statusDesc;
        Totally = totally;
    }

    public PrettyTablesOfOrders(String orderID,
                                String surName,
                                String roomNumber,
                                String statusDesc,
                                String totally) {
        OrderID = new SimpleStringProperty(orderID);
        SurName = new SimpleStringProperty(surName);
        RoomNumber = new SimpleStringProperty(roomNumber);
        StatusDesc = new SimpleStringProperty(statusDesc);
        Totally = new SimpleStringProperty(totally);
    }

    public String getOrderID() {
        return OrderID.get();
    }

    public SimpleStringProperty orderIDProperty() {
        return OrderID;
    }

    public void setOrderID(String orderID) {
        this.OrderID.set(orderID);
    }

    public String getSurName() {
        return SurName.get();
    }

    public SimpleStringProperty surNameProperty() {
        return SurName;
    }

    public void setSurName(String surName) {
        this.SurName.set(surName);
    }

    public String getRoomNumber() {
        return RoomNumber.get();
    }

    public SimpleStringProperty roomNumberProperty() {
        return RoomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.RoomNumber.set(roomNumber);
    }

    public String getStatusDesc() {
        return StatusDesc.get();
    }

    public SimpleStringProperty statusDescProperty() {
        return StatusDesc;
    }

    public void setStatusDesc(String statusDesc) {
        this.StatusDesc.set(statusDesc);
    }

    public String getTotally() {
        return Totally.get();
    }

    public SimpleStringProperty totallyProperty() {
        return Totally;
    }

    public void setTotally(String totally) {
        this.Totally.set(totally);
    }

    @Override
    public String toString() {
        return "PrettyTablesOfOrders{" +
                "OrderID=" + OrderID +
                ", SurName=" + SurName +
                ", RoomNumber=" + RoomNumber +
                ", StatusDesc=" + StatusDesc +
                ", Totally=" + Totally +
                '}';
    }
}
