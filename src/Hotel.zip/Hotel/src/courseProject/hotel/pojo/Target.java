package courseProject.hotel.pojo;

import javafx.beans.property.SimpleStringProperty;

public class Target {
    private SimpleStringProperty TargetID;
    private SimpleStringProperty TargetDesc;

    public Target(SimpleStringProperty targetID,
                  SimpleStringProperty targetDesc) {
        TargetID = targetID;
        TargetDesc = targetDesc;

    }

    public Target(String targetID, String targetDesc){
        TargetID = new SimpleStringProperty(targetID);
        TargetDesc = new SimpleStringProperty(targetDesc);
    }

    public String getTargetID() {
        return TargetID.get();
    }

    public SimpleStringProperty targetIDProperty() {
        return TargetID;
    }

    public void setTargetID(String targetID) {
        this.TargetID.set(targetID);
    }

    public String getTargetDesc() {
        return TargetDesc.get();
    }

    public SimpleStringProperty targetDescProperty() {
        return TargetDesc;
    }

    public void setTargetDesc(String targetDesc) {
        this.TargetDesc.set(targetDesc);
    }

    @Override
    public String toString() {
        return "Target{" +
                "TargetID=" + TargetID +
                ", TargetDesc=" + TargetDesc +
                '}';
    }
}

