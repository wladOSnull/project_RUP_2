package courseProject.hotel.SQL;

import courseProject.hotel.pojo.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.util.Properties;

public class SQLmain {

    private static Connection conn;

    // connect
    public SQLmain(){}

    public SQLmain(String argName,
            String argPass,
            String argHost,
            String argPort,
            String argSchema){

        System.out.println("***start MySQL***");

        // driver
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        // DB address
        String url = "jdbc:mysql://" + argHost + ":" + argPort + "/" + argSchema;

        Properties properties = new Properties();
        properties.setProperty("user", argName);
        properties.setProperty("password", argPass);
        properties.setProperty("useSSL", "false");
        properties.setProperty("autoReconnect", "true");

        try {
            // connection
            conn = DriverManager.getConnection(url, properties);
            System.out.println("Connection established.\n\n");
        } catch (SQLException ex){
            ex.printStackTrace();
        }

        System.out.println("***end MySQL***");
    }

    public SQLmain(LoginForm arg)throws SQLException{

        System.out.println("***start MySQL connection***");

        // driver
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        // DB address
        String url = "jdbc:mysql://" + arg.getHost() + ":" + arg.getPort() + "/" + arg.getSchema();

        Properties properties = new Properties();
        properties.setProperty("user", arg.getUser());
        properties.setProperty("password", arg.getPassword());
        properties.setProperty("useSSL", "false");
        properties.setProperty("autoReconnect", "true");
        properties.setProperty("characterEncoding", "UTF-8");

        System.out.println(url + " ... " + properties.toString());
//        try {
            // connection
            conn = DriverManager.getConnection(url, properties);
            System.out.println("Connection established.");
//        } catch (SQLException ex){
//            ex.printStackTrace();
//        }

        System.out.println("***end MySQL connection***");
    }

    public void endConnection(){
        try
        {
            conn.close();

        } catch (SQLException ex){
            System.out.println("ERROR connection close.\n\n");
        }
    }

    // special table
    public ObservableList<Account> getProfiles(){

        ResultSet res;
        ObservableList<Account> list = FXCollections.observableArrayList();

        try {
            // statement
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            res = stm.executeQuery("SELECT * FROM Profile");

            // make observable list
            while (res.next()) {

                list.add(new Account(res.getString("ProfileID"),
                        res.getString("Username"),
                        res.getString("Password"),
                        res.getString("ProfileDesc")));

            }

            stm.close();

        } catch (SQLException ex) {
            ex.printStackTrace();

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        return list;
    }

    public ObservableList getTableForStaff(){

        ResultSet res;
        ObservableList<TableOfRooms> list = FXCollections.observableArrayList();

        try {
            // statement
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            res = stm.executeQuery("select TypeRoom.RoomNumber, TypeRoom.TypeRoomDesc, Status.StatusDesc from TypeRoom\n" +
                                        "left join Orders on TypeRoom.OrderID = Orders.OrderID\n" +
                                        "left outer join Status on Orders.Status = Status.StatusID");

            TableOfRooms tor;
            // make observable list
            while (res.next()) {

                tor = new TableOfRooms(res.getString("RoomNumber"),
                                        res.getString("TypeRoomDesc"),
                                        res.getString("StatusDesc"));
                list.add(tor);
                System.out.println(tor.toString());
            }

            stm.close();

        } catch (SQLException ex) {
            ex.printStackTrace();

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        return list;
    }

    public ObservableList<PrettyTablesOfOrders> getPrettyOrdersTable(){

        ResultSet res;
        ObservableList<PrettyTablesOfOrders> list = FXCollections.observableArrayList();

        try {
            // statement
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            res = stm.executeQuery("select Orders.OrderID, Client.SurName, TypeRoom.RoomNumber, Status.StatusDesc, Totally\n" +
                    "from Orders\n" +
                    "left join Client on Orders.OrderID = Client.ClientID\n" +
                    "left join TypeRoom on Orders.TypeRoom = TypeRoom.TypeRoomID\n" +
                    "left join Status on Orders.Status = Status.StatusID");

            PrettyTablesOfOrders tor;
            // make observable list
            while (res.next()) {

                tor = new PrettyTablesOfOrders(res.getString("OrderID"),
                        res.getString("SurName"),
                        res.getString("RoomNumber"),
                        res.getString("StatusDesc"),
                        res.getString("Totally"));
                list.add(tor);
                System.out.println(tor.toString());
            }

            stm.close();

        } catch (SQLException ex) {
            ex.printStackTrace();

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        return list;
    }

    // special method
    public void updateExecute(String argQuery){

        try {
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stm.executeUpdate(argQuery);


        } catch (SQLException ex){
            ex.printStackTrace();
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
    }

    public void insertExecute(String argQuery){

        try {
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            stm.executeQuery(argQuery);


        } catch (SQLException ex){
            ex.printStackTrace();
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }
    }

    public ResultSet selectExecute(String argQuery){

        ResultSet res = null;

        try {
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            res = stm.executeQuery(argQuery);

        } catch (SQLException ex){
            ex.printStackTrace();
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        return res;
    }

    // default table
    public static ResultSet getDescriptionOfTable(String argNameTable){

        ResultSet res = null;

        try {
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            res = stm.executeQuery("DESCRIBE " + argNameTable);


        } catch (SQLException ex){
            ex.printStackTrace();
            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        return res;
    }

    public ObservableList<TypeRoom> getTypeRoom(){

        ResultSet res;
        ObservableList<TypeRoom> list = FXCollections.observableArrayList();

        try {
            // statement
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            res = stm.executeQuery("select * from TypeRoom");

            TypeRoom tor;
            // make observable list
            while (res.next()) {

                tor = new TypeRoom(res.getString("TypeRoomID"),
                        res.getString("RoomNumber"),
                        res.getString("TypeRoomDesc"),
                        res.getString("NumberPerson"),
                        res.getString("Price"));
                list.add(tor);
                System.out.println(tor.toString());
            }

            stm.close();

        } catch (SQLException ex) {
            ex.printStackTrace();

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        return list;
    }

    public ObservableList<TypePayment> getTypePayment(){

        ResultSet res;
        ObservableList<TypePayment> list = FXCollections.observableArrayList();

        try {
            // statement
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            res = stm.executeQuery("select * from TypePayment");

            TypePayment tor;
            // make observable list
            while (res.next()) {

                tor = new TypePayment(res.getString("TypePaymentID"),
                        res.getString("TypePaymentDesc"));
                list.add(tor);
                System.out.println(tor.toString());
            }

            stm.close();

        } catch (SQLException ex) {
            ex.printStackTrace();

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        return list;
    }

    public ObservableList<Target> getTarget(){

        ResultSet res;
        ObservableList<Target> list = FXCollections.observableArrayList();

        try {
            // statement
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            res = stm.executeQuery("select * from Target");

            Target tor;
            // make observable list
            while (res.next()) {

                tor = new Target(res.getString("TargetID"),
                        res.getString("TargetDesc"));

                list.add(tor);
                System.out.println(tor.toString());
            }

            stm.close();

        } catch (SQLException ex) {
            ex.printStackTrace();

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        return list;
    }

    public ObservableList<Status> getStatus(){

        ResultSet res;
        ObservableList<Status> list = FXCollections.observableArrayList();

        try {
            // statement
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            res = stm.executeQuery("select * from Status");

            Status tor;
            // make observable list
            while (res.next()) {

                tor = new Status(res.getString("StatusID"),
                        res.getString("StatusDesc"));

                list.add(tor);
                System.out.println(tor.toString());
            }

            stm.close();

        } catch (SQLException ex) {
            ex.printStackTrace();

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        return list;
    }

    public ObservableList getTypeSpecialOrders(){

        ResultSet res;
        ObservableList<TypeSpecialOrders> list = FXCollections.observableArrayList();

        try {
            // statement
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            res = stm.executeQuery("select * from TypeSpecialOrders");

            TypeSpecialOrders tor;
            // make observable list
            while (res.next()) {

                tor = new TypeSpecialOrders(res.getString("TypeSpecialOrdersID"),
                        res.getString("TypeSpecialOrdersName"),
                        res.getString("TypeSpecialOrdersDesc"));

                list.add(tor);
                System.out.println(tor.toString());
            }

            stm.close();

        } catch (SQLException ex) {
            ex.printStackTrace();

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        return list;
    }

    public ObservableList getSpecialOrders(){

        ResultSet res;
        ObservableList<SpecialOrders> list = FXCollections.observableArrayList();

        try {
            // statement
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            res = stm.executeQuery("select * from SpecialOrders");

            SpecialOrders tor;
            // make observable list
            while (res.next()) {

                tor = new SpecialOrders(res.getString("SpecialOrdersID"),
                        res.getString("SpecialOrdersName"),
                        res.getString("SpecialOrdersDesc"),
                        res.getString("Price"),
                        res.getString("SpecialOrdersType"));

                list.add(tor);
                System.out.println(tor.toString());
            }

            stm.close();

        } catch (SQLException ex) {
            ex.printStackTrace();

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        return list;
    }

    public ObservableList<Orders> getOrders(int arg){

        ResultSet res;
        ObservableList<Orders> list = FXCollections.observableArrayList();

        try {
            // statement
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            res = stm.executeQuery("select * from Orders where=" + arg);

            Orders tor;
            // make observable list
            while (res.next()) {

                tor = new Orders(res.getString("OrderID"),
                        res.getString("Client"),
                        res.getString("TypeRoom"),
                        res.getString("TypePayment"),
                        res.getString("Status"),
                        res.getString("DateArrival"),
                        res.getString("DateDeparture"),
                        res.getString("Wish"),
                        res.getString("Totally"));

                list.add(tor);
                System.out.println(tor.toString());
            }

            stm.close();

        } catch (SQLException ex) {
            ex.printStackTrace();

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        return list;
    }

    public ObservableList getClient(){

        ResultSet res;
        ObservableList<Client> list = FXCollections.observableArrayList();

        try {
            // statement
            Statement stm = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            res = stm.executeQuery("select Client.ClientID, Client.FirstName, Client.SurName, Client.Address, Client.Passport, Client.Number, Client.Citizenship, Target.TargetDesc\n" +
                    "from Client\n" +
                    "left join Target on Client.Target = Target.TargetID;");

            Client tor;
            // make observable list
            while (res.next()) {

                tor = new Client(res.getString("ClientID"),
                        res.getString("FirstName"),
                        res.getString("SurName"),
                        res.getString("Address"),
                        res.getString("Passport"),
                        res.getString("Number"),
                        res.getString("Citizenship"),
                        res.getString("TargetDesc"));

                list.add(tor);
                System.out.println(tor.toString());
            }

            stm.close();

        } catch (SQLException ex) {
            ex.printStackTrace();

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        }

        return list;
    }
}
