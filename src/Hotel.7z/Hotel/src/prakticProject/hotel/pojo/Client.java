package courseProject.hotel.pojo;

import javafx.beans.property.SimpleStringProperty;

public class Client {
    private SimpleStringProperty ClientID;
    private SimpleStringProperty FirstName;
    private SimpleStringProperty SurName;
    private SimpleStringProperty Address;
    private SimpleStringProperty Passport;
    private SimpleStringProperty Number;
    private SimpleStringProperty Citizenship;
    private SimpleStringProperty Target;

    public Client(SimpleStringProperty clientID,
                  SimpleStringProperty firstName,
                  SimpleStringProperty surName,
                  SimpleStringProperty address,
                  SimpleStringProperty passport,
                  SimpleStringProperty number,
                  SimpleStringProperty citizenship,
                  SimpleStringProperty target) {
        ClientID = clientID;
        FirstName = firstName;
        SurName = surName;
        Address = address;
        Passport = passport;
        Number = number;
        Citizenship = citizenship;
        Target = target;
    }

    public Client(String clientID,
                  String firstName,
                  String surName,
                  String address,
                  String passport,
                  String number,
                  String citizenship,
                  String target) {
        ClientID = new SimpleStringProperty(clientID);
        FirstName = new SimpleStringProperty(firstName);
        SurName = new SimpleStringProperty(surName);
        Address = new SimpleStringProperty(address);
        Passport = new SimpleStringProperty(passport);
        Number = new SimpleStringProperty(number);
        Citizenship = new SimpleStringProperty(citizenship);
        Target = new SimpleStringProperty(target);
    }

    public String getClientID() {
        return ClientID.get();
    }

    public SimpleStringProperty clientIDProperty() {
        return ClientID;
    }

    public void setClientID(String clientID) {
        this.ClientID.set(clientID);
    }

    public String getFirstName() {
        return FirstName.get();
    }

    public SimpleStringProperty firstNameProperty() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        this.FirstName.set(firstName);
    }

    public String getSurName() {
        return SurName.get();
    }

    public SimpleStringProperty surNameProperty() {
        return SurName;
    }

    public void setSurName(String surName) {
        this.SurName.set(surName);
    }

    public String getAddress() {
        return Address.get();
    }

    public SimpleStringProperty addressProperty() {
        return Address;
    }

    public void setAddress(String address) {
        this.Address.set(address);
    }

    public String getPassport() {
        return Passport.get();
    }

    public SimpleStringProperty passportProperty() {
        return Passport;
    }

    public void setPassport(String passport) {
        this.Passport.set(passport);
    }

    public String getNumber() {
        return Number.get();
    }

    public SimpleStringProperty numberProperty() {
        return Number;
    }

    public void setNumber(String number) {
        this.Number.set(number);
    }

    public String getCitizenship() {
        return Citizenship.get();
    }

    public SimpleStringProperty citizenshipProperty() {
        return Citizenship;
    }

    public void setCitizenship(String citizenship) {
        this.Citizenship.set(citizenship);
    }

    public String getTarget() {
        return Target.get();
    }

    public SimpleStringProperty targetProperty() {
        return Target;
    }

    public void setTarget(String target) {
        this.Target.set(target);
    }

    @Override
    public String toString() {
        return "Client{" +
                "ClientID=" + ClientID +
                ", FirstName=" + FirstName +
                ", SurName=" + SurName +
                ", Address=" + Address +
                ", Passport=" + Passport +
                ", Number=" + Number +
                ", Citizenship=" + Citizenship +
                ", Target=" + Target +
                '}';
    }
}
