package courseProject.hotel.pojo;

import javafx.beans.property.SimpleStringProperty;

public class Account {

    // fields
    private SimpleStringProperty id;
    private SimpleStringProperty user;
    private SimpleStringProperty password;
    private SimpleStringProperty description;

    // constructors
    public Account(SimpleStringProperty id,
                   SimpleStringProperty user,
                   SimpleStringProperty password,
                   SimpleStringProperty description) {
        this.id = id;
        this.user = user;
        this.password = password;
        this.description = description;
    }

    public Account(String id, String user, String password, String description){
        this.id = new SimpleStringProperty(id);
        this.user = new SimpleStringProperty(user);
        this.password = new SimpleStringProperty(password);
        this.description = new SimpleStringProperty(description);
    }

    public Account() {}

    // get / set
    public String getId() {
        return id.get();
    }

    public SimpleStringProperty idProperty() {
        return id;
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public String getUser() {
        return user.get();
    }

    public SimpleStringProperty userProperty() {
        return user;
    }

    public void setUser(String user) {
        this.user.set(user);
    }

    public String getPassword() {
        return password.get();
    }

    public SimpleStringProperty passwordProperty() {
        return password;
    }

    public void setPassword(String password) {
        this.password.set(password);
    }

    public String getDescribtion() {
        return description.get();
    }

    public SimpleStringProperty describtionProperty() {
        return description;
    }

    public void setDescribtion(String describtion) {
        this.description.set(describtion);
    }

    @Override
    public String toString() {
        return "Account{" +
                "id=" + id +
                ", user=" + user +
                ", password=" + password +
                ", describtion=" + description +
                '}';
    }
}
