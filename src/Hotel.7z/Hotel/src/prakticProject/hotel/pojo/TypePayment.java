package courseProject.hotel.pojo;

import javafx.beans.property.SimpleStringProperty;

public class TypePayment {
    private SimpleStringProperty TypePaymentID;
    private SimpleStringProperty TypePaymentDesc;

    public TypePayment(){}

    public TypePayment(SimpleStringProperty typePaymentID,
                       SimpleStringProperty typePaymentDesc) {
        TypePaymentID = typePaymentID;
        TypePaymentDesc = typePaymentDesc;
    }

    public TypePayment(String typePaymentID, String typePaymentDesc){
        TypePaymentID = new SimpleStringProperty(typePaymentID);
        TypePaymentDesc = new SimpleStringProperty(typePaymentDesc);
    }

    public String getTypePaymentID() {
        return TypePaymentID.get();
    }

    public SimpleStringProperty typePaymentIDProperty() {
        return TypePaymentID;
    }

    public void setTypePaymentID(String typePaymentID) {
        this.TypePaymentID.set(typePaymentID);
    }

    public String getTypePaymentDesc() {
        return TypePaymentDesc.get();
    }

    public SimpleStringProperty typePaymentDescProperty() {
        return TypePaymentDesc;
    }

    public void setTypePaymentDesc(String typePaymentDesc) {
        this.TypePaymentDesc.set(typePaymentDesc);
    }

    @Override
    public String toString() {
        return "TypePayment{" +
                "TypePaymentID=" + TypePaymentID +
                ", TypePaymentDesc=" + TypePaymentDesc +
                '}';
    }
}
