package courseProject.hotel.pojo;

import javafx.beans.property.SimpleStringProperty;

public class Orders {
    private SimpleStringProperty OrderID;
    private SimpleStringProperty Client;
    private SimpleStringProperty TypeRoom;
    private SimpleStringProperty TypePayment;
    private SimpleStringProperty Status;
    private SimpleStringProperty DateArrival;
    private SimpleStringProperty DateDeparture;
    private SimpleStringProperty Wish;
    private SimpleStringProperty Totally;

    public Orders(SimpleStringProperty orderID,
                  SimpleStringProperty client,
                  SimpleStringProperty typeRoom,
                  SimpleStringProperty typePayment,
                  SimpleStringProperty status,
                  SimpleStringProperty dateArrival,
                  SimpleStringProperty dateDeparture,
                  SimpleStringProperty wish,
                  SimpleStringProperty totally) {
        OrderID = orderID;
        Client = client;
        TypeRoom = typeRoom;
        TypePayment = typePayment;
        Status = status;
        DateArrival = dateArrival;
        DateDeparture = dateDeparture;
        Wish = wish;
        Totally = totally;
    }

    public Orders(String orderID,
                  String client,
                  String typeRoom,
                  String typePayment,
                  String status,
                  String dateArrival,
                  String dateDeparture,
                  String wish,
                  String totally) {
        OrderID = new SimpleStringProperty(orderID);
        Client = new SimpleStringProperty(client);
        TypeRoom = new SimpleStringProperty(typeRoom);
        TypePayment = new SimpleStringProperty(typePayment);
        Status = new SimpleStringProperty(status);
        DateArrival = new SimpleStringProperty(dateArrival);
        DateDeparture = new SimpleStringProperty(dateDeparture);
        Wish = new SimpleStringProperty(wish);
        Totally = new SimpleStringProperty(totally);
    }

    public String getOrderID() {
        return OrderID.get();
    }

    public SimpleStringProperty orderIDProperty() {
        return OrderID;
    }

    public void setOrderID(String orderID) {
        this.OrderID.set(orderID);
    }

    public String getClient() {
        return Client.get();
    }

    public SimpleStringProperty clientProperty() {
        return Client;
    }

    public void setClient(String client) {
        this.Client.set(client);
    }

    public String getTypeRoom() {
        return TypeRoom.get();
    }

    public SimpleStringProperty typeRoomProperty() {
        return TypeRoom;
    }

    public void setTypeRoom(String typeRoom) {
        this.TypeRoom.set(typeRoom);
    }

    public String getTypePayment() {
        return TypePayment.get();
    }

    public SimpleStringProperty typePaymentProperty() {
        return TypePayment;
    }

    public void setTypePayment(String typePayment) {
        this.TypePayment.set(typePayment);
    }

    public String getStatus() {
        return Status.get();
    }

    public SimpleStringProperty statusProperty() {
        return Status;
    }

    public void setStatus(String status) {
        this.Status.set(status);
    }

    public String getDateArrival() {
        return DateArrival.get();
    }

    public SimpleStringProperty dateArrivalProperty() {
        return DateArrival;
    }

    public void setDateArrival(String dateArrival) {
        this.DateArrival.set(dateArrival);
    }

    public String getDateDeparture() {
        return DateDeparture.get();
    }

    public SimpleStringProperty dateDepartureProperty() {
        return DateDeparture;
    }

    public void setDateDeparture(String dateDeparture) {
        this.DateDeparture.set(dateDeparture);
    }

    public String getWish() {
        return Wish.get();
    }

    public SimpleStringProperty wishProperty() {
        return Wish;
    }

    public void setWish(String wish) {
        this.Wish.set(wish);
    }

    public String getTotally() {
        return Totally.get();
    }

    public SimpleStringProperty totallyProperty() {
        return Totally;
    }

    public void setTotally(String totally) {
        this.Totally.set(totally);
    }

    @Override
    public String toString() {
        return "Orders{" +
                "OrderID=" + OrderID +
                ", Client=" + Client +
                ", TypeRoom=" + TypeRoom +
                ", TypePayment=" + TypePayment +
                ", Status=" + Status +
                ", DateArrival=" + DateArrival +
                ", DateDeparture=" + DateDeparture +
                ", Wish=" + Wish +
                ", Totally=" + Totally +
                '}';
    }
}
