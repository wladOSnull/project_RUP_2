package courseProject.hotel.pojo;

import javafx.beans.property.SimpleStringProperty;

public class SpecialOrders {
    private SimpleStringProperty SpecialOrdersID;
    private SimpleStringProperty SpecialOrdersName;
    private SimpleStringProperty SpecialOrdersDesc;
    private SimpleStringProperty Price;
    private SimpleStringProperty SpecialOrdersType;

    public SpecialOrders(SimpleStringProperty specialOrdersID,
                         SimpleStringProperty specialOrdersName,
                         SimpleStringProperty specialOrdersDesc,
                         SimpleStringProperty price,
                         SimpleStringProperty specialOrdersType) {
        SpecialOrdersID = specialOrdersID;
        SpecialOrdersName = specialOrdersName;
        SpecialOrdersDesc = specialOrdersDesc;
        Price = price;
        SpecialOrdersType = specialOrdersType;
    }

    public SpecialOrders(String specialOrdersID,
                         String specialOrdersName,
                         String specialOrdersDesc,
                         String price,
                         String specialOrdersType){

        SpecialOrdersID = new SimpleStringProperty(specialOrdersID);
        SpecialOrdersName = new SimpleStringProperty(specialOrdersName);
        SpecialOrdersDesc = new SimpleStringProperty(specialOrdersDesc);
        Price = new SimpleStringProperty(price);
        SpecialOrdersType = new SimpleStringProperty(specialOrdersType);
    }

    public String getSpecialOrdersID() {
        return SpecialOrdersID.get();
    }

    public SimpleStringProperty specialOrdersIDProperty() {
        return SpecialOrdersID;
    }

    public void setSpecialOrdersID(String specialOrdersID) {
        this.SpecialOrdersID.set(specialOrdersID);
    }

    public String getSpecialOrdersName() {
        return SpecialOrdersName.get();
    }

    public SimpleStringProperty specialOrdersNameProperty() {
        return SpecialOrdersName;
    }

    public void setSpecialOrdersName(String specialOrdersName) {
        this.SpecialOrdersName.set(specialOrdersName);
    }

    public String getSpecialOrdersDesc() {
        return SpecialOrdersDesc.get();
    }

    public SimpleStringProperty specialOrdersDescProperty() {
        return SpecialOrdersDesc;
    }

    public void setSpecialOrdersDesc(String specialOrdersDesc) {
        this.SpecialOrdersDesc.set(specialOrdersDesc);
    }

    public String getPrice() {
        return Price.get();
    }

    public SimpleStringProperty priceProperty() {
        return Price;
    }

    public void setPrice(String price) {
        this.Price.set(price);
    }

    public String getSpecialOrdersType() {
        return SpecialOrdersType.get();
    }

    public SimpleStringProperty specialOrdersTypeProperty() {
        return SpecialOrdersType;
    }

    public void setSpecialOrdersType(String specialOrdersType) {
        this.SpecialOrdersType.set(specialOrdersType);
    }

    @Override
    public String toString() {
        return "SpecialOrders{" +
                "SpecialOrdersID=" + SpecialOrdersID +
                ", SpecialOrdersName=" + SpecialOrdersName +
                ", SpecialOrdersDesc=" + SpecialOrdersDesc +
                ", Price=" + Price +
                ", SpecialOrdersType=" + SpecialOrdersType +
                '}';
    }
}
