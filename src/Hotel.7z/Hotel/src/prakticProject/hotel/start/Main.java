package courseProject.hotel.start;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.sql.*;
import java.util.Properties;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("../fxml/mainWindow.fxml"));
        primaryStage.setTitle(":: Visual Hotel ::");
        primaryStage.setScene(new Scene(root, 800, 430));
        primaryStage.setMinWidth(600);
        primaryStage.setMinHeight(430);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);

//        sqlConnTest();
    }

    private static void sqlConnTest(){

        System.out.println("***start MySQL***");

        // driver
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        // DB address
        String url = "jdbc:mysql://localhost:3306/DB_test1";

        Properties properties = new Properties();
        properties.setProperty("user", "wlados");
        properties.setProperty("password", "mysql");
        properties.setProperty("useSSL", "false");
        properties.setProperty("autoReconnect", "true");

        Connection conn;

        try {
            // connection
            conn = DriverManager.getConnection(url, properties);
            System.out.println("Connection established.");
            conn.close();
        } catch (SQLException ex){
            ex.printStackTrace();
        }

        System.out.println("***end MySQL***");
    }
}
