package courseProject.hotel.controllers;

import courseProject.hotel.SQL.SQLmain;
import courseProject.hotel.pojo.Client;
import courseProject.hotel.pojo.Orders;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.Hashtable;

public class ControllerChange {

    // data
    private static Orders order;
    private static Client client;

    // FXML
    public Button buttonCancel;
    public Button buttonOK;
    public TextField textFieldName;
    public TextField textFieldSurname;
    public TextField textFieldNumber;
    public TextField textFieldPassport;
    public TextField textFieldAddress;
    public TextField textFieldCitizenship;
    public TextField textFieldWish;
    public TextField textFieldID;
    public TextField textFieldTotal;
    public DatePicker dataPickerArrival;
    public DatePicker dataPickerDeparture;
    public Label labelCheck;
    public ChoiceBox choiceBoxTarget;
    public ChoiceBox choiceBoxTypeRoom;
    public ChoiceBox choiceBoxTypePayment;
    public ChoiceBox choiceBoxStatus;

    // SQL
    public static SQLmain mSQL;
    public static ResultSet rs;

    // Boxes
    private Hashtable<String, String> listTarget;
    private Hashtable<String, String> listTypeRoom;
    private Hashtable<String, String> listTypePayment;
    private Hashtable<String, String> listStatus;

    private Hashtable<String, String> revListTarget;
    private Hashtable<String, String> revListTypeRoom;
    private Hashtable<String, String> revListTypePayment;
    private Hashtable<String, String> revListStatus;

    // main
    private String id;
    private Client clientAcc;
    private String room;

    // actions
    public void actionOK() {

        fillOrder();

        actionClose();
    }

    public void actionClose() {
        Stage stage = (Stage) buttonCancel.getScene().getWindow();
        stage.close();
    }

    // methods
    @FXML
    public void initialize() {

        listTarget = new Hashtable<String, String>();
        revListTarget = new Hashtable<>();
        mSQL.getTarget().forEach((str) -> {

            choiceBoxTarget.getItems().addAll(str.getTargetDesc());
            listTarget.put(str.getTargetDesc(), str.getTargetID());
            revListTarget.put(str.getTargetID(), str.getTargetDesc());
        });

        listTypeRoom = new Hashtable<String, String>();
        revListTypeRoom = new Hashtable<>();
        mSQL.getTypeRoom().forEach((str) -> {
            choiceBoxTypeRoom.getItems().addAll(str.getTypeRoomDesc().concat(" x:").concat(str.getNumberPerson()).concat(" p:").concat(str.getPrice()));
            listTypeRoom.put(str.getTypeRoomDesc().concat(" x:").concat(str.getNumberPerson()).concat(" p:").concat(str.getPrice()), str.getTypeRoomID());
            revListTypeRoom.put(str.getTypeRoomID(), str.getTypeRoomDesc().concat(" x:").concat(str.getNumberPerson()).concat(" p:").concat(str.getPrice()));
        });

        listTypePayment = new Hashtable<String, String>();
        revListTypePayment = new Hashtable<>();
        mSQL.getTypePayment().forEach((str) -> {
            choiceBoxTypePayment.getItems().addAll(str.getTypePaymentDesc());
            listTypePayment.put(str.getTypePaymentDesc(), str.getTypePaymentID());
            revListTypePayment.put(str.getTypePaymentID(), str.getTypePaymentDesc());
        });

        listStatus = new Hashtable<String, String>();
        revListStatus = new Hashtable<>();
        mSQL.getStatus().forEach((str) -> {
            choiceBoxStatus.getItems().addAll(str.getStatusDesc());
            listStatus.put(str.getStatusDesc(), str.getStatusID());
            revListStatus.put(str.getStatusID(), str.getStatusDesc());
        });

        try {
            rs.next();
            id = rs.getString("OrderID");

            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            Date date = format.parse(rs.getString("DateArrival"));

            dataPickerArrival.setValue(LocalDate.of(date.getYear() + 1900, date.getMonth() + 1, date.getDay() + 2));
            System.out.println("DATE:" + Integer.toString(date.getYear()) + " " + Integer.toString(date.getMonth()) + " " + Integer.toString(date.getDay()) + " " + rs.getString("DateArrival"));

            date = format.parse(rs.getString("DateDeparture"));
            dataPickerDeparture.setValue(LocalDate.of(date.getYear() + 1900, date.getMonth() + 1, date.getDay() + 2));

            textFieldWish.setText(rs.getString("Wish"));
            textFieldTotal.setText(rs.getString("Totally"));

            String query = "SELECT * FROM Client WHERE ClientID=" + id;
            ResultSet rsClient = mSQL.selectExecute(query);

            rsClient.next();
            textFieldName.setText(rsClient.getString("FirstName"));
            textFieldSurname.setText(rsClient.getString("SurName"));
            textFieldID.setText(rsClient.getString("ClientID"));
            textFieldAddress.setText(rsClient.getString("Address"));
            textFieldAddress.setText(rsClient.getString("Address"));
            textFieldPassport.setText(rsClient.getString("Passport"));
            textFieldNumber.setText(rsClient.getString("Number"));
            textFieldCitizenship.setText(rsClient.getString("Citizenship"));

            choiceBoxTarget.setValue(revListTarget.get(rsClient.getString("Target")));
            choiceBoxTypeRoom.setValue(revListTypeRoom.get(rs.getString("TypeRoom")));
            System.out.println("CHOICE BOX FILL: " + rs.getString("TypeRoom") + " " + revListTypeRoom.get(rs.getString("TypeRoom")));
            room = rs.getString("TypeRoom");
            choiceBoxStatus.setValue(revListStatus.get(rs.getString("Status")));
            choiceBoxTypePayment.setValue(revListTypePayment.get(rs.getString("TypePayment")));

        } catch (SQLException ex) {
            ex.printStackTrace();

            System.out.println("SQLException: " + ex.getMessage());
            System.out.println("SQLState: " + ex.getSQLState());
            System.out.println("VendorError: " + ex.getErrorCode());
        } catch (ParseException ex2) {
            ex2.printStackTrace();
        }
    }

    public void display(javafx.scene.control.MenuBar menuBarMainWindow, SQLmain argSQL, ResultSet argRS) {

        System.out.println("Edit order");

        try {
            Stage parent = (Stage) menuBarMainWindow.getScene().getWindow();

            Stage stage = new Stage();
            Parent root = FXMLLoader.load(getClass().getResource("../fxml/orderChange.fxml"));
//            Parent root = FXMLLoader.load(getClass().getResource("../fxml/test.fxml"));
            stage.setTitle("Order details");
            stage.setMinWidth(430);
            stage.setMinHeight(330);
            stage.setResizable(false);
            stage.setScene(new Scene(root));
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(parent);

            stage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
        }


        rs = argRS;
        mSQL = argSQL;
    }

    private void fillOrder() {
        java.util.Date date = java.util.Date.from(dataPickerArrival.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
        java.sql.Date sqlDateArrival = new java.sql.Date(date.getTime());
        System.out.print("DATE: " + sqlDateArrival.toString() + " / ");

        date = java.util.Date.from(dataPickerDeparture.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
        java.sql.Date sqlDateDeparture = new java.sql.Date(date.getTime());
        System.out.println("DATE: " + sqlDateArrival.toString());

        String target = listTarget.get(choiceBoxTarget.getSelectionModel().getSelectedItem());
        String query = "UPDATE Client SET " +
                "FirstName='" + textFieldName.getText() + "', " +
                "SurName='" + textFieldSurname.getText() + "', " +
                "Address='" + textFieldAddress.getText() + "', " +
                "Passport='" + textFieldPassport.getText() + "', " +
                "Number='" + textFieldNumber.getText() + "', " +
                "Citizenship='" + textFieldCitizenship.getText() + "', " +
                "Target=" + target +
                " WHERE ClientID=" + textFieldID.getText();

        System.out.println("UPDATE Client: " + query);
        mSQL.updateExecute(query);

        query = "UPDATE Orders SET Client=" + textFieldID.getText() + ", " +
                "TypeRoom=" + listTypeRoom.get(choiceBoxTypeRoom.getSelectionModel().getSelectedItem()) + ", " +
                "TypePayment=" + listTypePayment.get(choiceBoxTypePayment.getSelectionModel().getSelectedItem()) + ", " +
                "Status=" + listStatus.get(choiceBoxStatus.getSelectionModel().getSelectedItem()) + ", " +
                "DateArrival='" + sqlDateArrival.toString() + "', " +
                "DateDeparture='" + sqlDateDeparture.toString() + "', " +
                "Wish='" + textFieldWish.getText() + "', " +
                "Totally=" + textFieldTotal.getText() +
                " WHERE OrderID=" + id;

        System.out.println("UPDATE Orders: " + query);
        mSQL.updateExecute(query);

        String select;

            query = "UPDATE TypeRoom SET TypeRoom.OrderID=null WHERE TypeRoomID=" + room;
            System.out.println("UPDATE NULL rooms: " + query);
            mSQL.updateExecute(query);
            query = "UPDATE TypeRoom SET TypeRoom.OrderID=" + id + " WHERE TypeRoomID=" + listTypeRoom.get(choiceBoxTypeRoom.getSelectionModel().getSelectedItem());
            System.out.println("UPDATE NEW rooms: " + query);
            mSQL.updateExecute(query);

    }
}

